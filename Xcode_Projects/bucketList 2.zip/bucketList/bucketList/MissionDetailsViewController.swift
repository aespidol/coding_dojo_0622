//
//  MissionDetailsViewController.swift
//  bucketList
//
//  Created by Andrew Espidol on 9/7/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

class MissionDetailsViewController: UITableViewController {
    weak var cancelButtonDelegate: CancelButtonDelegate?
    @IBOutlet weak var newMissionText: UITextField!
    @IBAction func cancelBarButtonPressed(sender: UIBarButtonItem) {
        cancelButtonDelegate?.cancelButtonPressedFrom(self)
    }
    @IBAction func doneBarButtonPressed(sender: UIBarButtonItem) {
        if let mission = missionToEdit {
            mission.objective = newMissionText.text!
            delegate?.missionDetailsViewController(self, didFinishEditingMission: mission)
        } else {
            let mission = Mission(obj: newMissionText.text!)
            delegate?.missionDetailsViewController(self, didFinishAddingMission: mission.objective)
        }
        
    }
    weak var delegate: MissionDetailsViewControllerDelegate?
    var missionToEdit: Mission?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if missionToEdit != nil {
            newMissionText.text = missionToEdit!.objective
        }
    }
}
