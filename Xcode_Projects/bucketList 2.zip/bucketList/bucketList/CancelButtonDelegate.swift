//
//  CancelButtonDelegate.swift
//  bucketList
//
//  Created by Andrew Espidol on 9/7/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

protocol CancelButtonDelegate: class {
    func cancelButtonPressedFrom(controller: UIViewController)
}
