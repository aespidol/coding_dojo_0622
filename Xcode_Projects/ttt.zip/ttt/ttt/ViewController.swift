//
//  ViewController.swift
//  ttt
//
//  Created by Andrew Espidol on 9/4/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var turn = 1;
    var tic = [0,0,0,0,0,0,0,0,0]
    @IBOutlet weak var winningLabel: UILabel!
    
    @IBOutlet weak var tile0: UIButton!
    @IBOutlet weak var tile1: UIButton!
    @IBOutlet weak var tile2: UIButton!
    @IBOutlet weak var tile3: UIButton!
    @IBOutlet weak var tile4: UIButton!
    @IBOutlet weak var tile5: UIButton!
    @IBOutlet weak var tile6: UIButton!
    @IBOutlet weak var tile7: UIButton!
    @IBOutlet weak var tile8: UIButton!
    
    @IBAction func ticButton(sender: UIButton) {
        print(sender.tag)
        if turn == 1 {
            sender.backgroundColor = .redColor()
            tic[sender.tag] = turn
            print(tic)
            turn = 2
        }
        else {
            sender.backgroundColor = .blueColor()
            tic[sender.tag] = turn

            print(tic)
            turn = 1
        }
        if tic[0] == 1 && tic[2] == 1 && tic [1] == 1{
            winningLabel.text = "Red wins"
            winningLabel.hidden = false
        } else if tic[0] == 1 && tic[3] == 1 && tic[6] == 1 {
            winningLabel.text = "Red wins"
            winningLabel.hidden = false
        } else if tic[0] == 1 && tic[4] == 1 && tic[8] == 1 {
            winningLabel.text = "Red wins"
            winningLabel.hidden = false
        } else if tic[1] == 1 && tic[4] == 1 && tic[7] == 1 {
            winningLabel.text = "Red Wins"
            winningLabel.hidden = false
        } else if tic[2] == 1 && tic[5] == 1 && tic[8] == 1{
            winningLabel.text = "Red Wins"
            winningLabel.hidden = false
        } else if tic[2] == 1 && tic[4] == 1 && tic[6] == 1 {
            winningLabel.text = "Red Wins"
            winningLabel.hidden = false
        } else if tic[3] == 1 && tic[4] == 1 && tic[5] == 1 {
            winningLabel.text = "Red Wins"
            winningLabel.hidden = false
        } else if tic[6] == 1 && tic[7] == 1 && tic[8] == 1 {
            winningLabel.text = "Red Wins"
            winningLabel.hidden = false
        }
        if tic[0] == 2 && tic[2] == 2 && tic [1] == 2{
            winningLabel.text = "Blue wins"
            winningLabel.hidden = false
        } else if tic[0] == 2 && tic[3] == 2 && tic[6] == 2 {
            winningLabel.text = "Blue wins"
            winningLabel.hidden = false
        } else if tic[0] == 2 && tic[4] == 2 && tic[8] == 2 {
            winningLabel.text = "Blue wins"
            winningLabel.hidden = false
        } else if tic[1] == 2 && tic[4] == 2 && tic[7] == 2 {
            winningLabel.text = "Blue Wins"
            winningLabel.hidden = false
        } else if tic[2] == 2 && tic[5] == 2 && tic[8] == 2{
            winningLabel.text = "Blue Wins"
            winningLabel.hidden = false
        } else if tic[2] == 2 && tic[4] == 2 && tic[6] == 2 {
            winningLabel.text = "Blue Wins"
            winningLabel.hidden = false
        } else if tic[3] == 2 && tic[4] == 2 && tic[5] == 2 {
            winningLabel.text = "Blue Wins"
            winningLabel.hidden = false
        } else if tic[6] == 2 && tic[7] == 2 && tic[8] == 2 {
            winningLabel.text = "Blue Wins"
            winningLabel.hidden = false
        }

    }
    
    @IBAction func resetButton(sender: UIButton) {
        tic = [0,0,0,0,0,0,0,0,0]
        tile0.backgroundColor = UIColor.lightGrayColor()
        tile1.backgroundColor = UIColor.lightGrayColor()
        tile2.backgroundColor = UIColor.lightGrayColor()
        tile3.backgroundColor = UIColor.lightGrayColor()
        tile4.backgroundColor = UIColor.lightGrayColor()
        tile5.backgroundColor = UIColor.lightGrayColor()
        tile6.backgroundColor = UIColor.lightGrayColor()
        tile7.backgroundColor = UIColor.lightGrayColor()
        tile8.backgroundColor = UIColor.lightGrayColor()
        winningLabel.hidden = true
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        winningLabel.hidden = true
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

