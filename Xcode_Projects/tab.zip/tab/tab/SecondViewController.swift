//
//  SecondViewController.swift
//  tab
//
//  Created by Andrew Espidol on 9/7/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        print("SecondViewController viewDidLoad")
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        print("SecondView Controller viewWillAppear")
    }
}