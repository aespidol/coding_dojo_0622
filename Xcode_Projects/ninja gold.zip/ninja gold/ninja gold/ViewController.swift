//
//  ViewController.swift
//  ninja gold
//
//  Created by Andrew Espidol on 9/3/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var ninjaScore = 0;
    @IBOutlet weak var scoreLabel: UILabel!
    
    
    @IBOutlet weak var farmLabel: UILabel!
    @IBOutlet weak var caveLabel: UILabel!
    @IBOutlet weak var houseLabel: UILabel!
    @IBOutlet weak var casinoLabel: UILabel!

    @IBAction func resetButton(sender: UIButton) {
        ninjaScore = 0;
        scoreLabel.text = String(ninjaScore)
        farmLabel.hidden = true
        caveLabel.hidden = true
        houseLabel.hidden = true
        casinoLabel.hidden = true
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        scoreLabel.text = String(ninjaScore)
        farmLabel.hidden = true
        caveLabel.hidden = true
        houseLabel.hidden = true
        casinoLabel.hidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func buildingButtonPressed(sender: UIButton) {
        print(sender.tag)
        farmLabel.hidden = true
        caveLabel.hidden = true
        houseLabel.hidden = true
        casinoLabel.hidden = true
        if sender.tag == 1 {
            let increment = arc4random_uniform(20-10) + 10
            print(increment)
            ninjaScore = Int(ninjaScore) + Int(increment)
            scoreLabel.text = String(ninjaScore)
            farmLabel.text = "You earned "+String(increment)+" gold"
            farmLabel.hidden = false;
        }
        else if sender.tag == 2 {
            let increment = arc4random_uniform(10-5) + 5
            print(increment)
            ninjaScore = Int(ninjaScore) + Int(increment)
            scoreLabel.text = String(ninjaScore)
            caveLabel.text = "You earned "+String(increment)+" gold"
            caveLabel.hidden = false
        }
        else if sender.tag == 3 {
            let increment = arc4random_uniform(5-2) + 5
            print(increment)
            ninjaScore = Int(ninjaScore) + Int(increment)
            scoreLabel.text = String(ninjaScore)
            houseLabel.text = "You earned "+String(increment)+" gold"
            houseLabel.hidden = false
        }
        else if sender.tag == 4 {
            let increment = arc4random_uniform(50)
            print(increment)
            let rand = arc4random_uniform(2)
            if rand == 0 {
                ninjaScore = Int(ninjaScore) - Int(increment)
                scoreLabel.text = String(ninjaScore)
                casinoLabel.text = "You lost "+String(increment)+" gold"
                casinoLabel.hidden = false
            } else {
                ninjaScore = Int(ninjaScore) + Int(increment)
                scoreLabel.text = String(ninjaScore)
                casinoLabel.text = "You earned "+String(increment)+" gold"
                casinoLabel.hidden = false
            }
        }
    }

}

