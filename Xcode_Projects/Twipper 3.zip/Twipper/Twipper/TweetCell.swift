//
//  TweetCell.swift
//  Twipper
//
//  Created by Andrew Espidol on 9/8/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

class TweetCell: UITableViewCell {
    @IBOutlet weak var pictureImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var tweetTextLabel: UILabel!
    @IBOutlet weak var createdAtLabel: UILabel!
    
}
