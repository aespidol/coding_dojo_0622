//
//  ViewController.swift
//  Twipper
//
//  Created by Andrew Espidol on 9/8/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit
import Social
import Accounts

class TweetController: UITableViewController {
    var tweets = [
        Tweet(tweetText: "tweet one", userName: "userOne", createdAt: "Wed May 06", pictureURL: NSURL(string:"http://lorempixel.com/200/200/")),
        Tweet(tweetText: "tweet two", userName: "userTwo", createdAt: "Wed May 06", pictureURL: NSURL(string: "http://lorempixel.com/201/201/")),
        Tweet(tweetText: "tweet three", userName: "userTwo", createdAt: "Wed May 06", pictureURL: NSURL(string: "http://lorempixel.com/202/202/")),
        Tweet(tweetText: "tweet four", userName: "userThree", createdAt: "Wed May 06", pictureURL: NSURL(string: "http://lorempixel.com/203/203/"))
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        requestTweets()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tweets.count
    }
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("TweetCell") as! TweetCell
        let tweet = tweets[indexPath.row]
        
        cell.tweetTextLabel.text = tweet.tweetText
        cell.userNameLabel.text = tweet.userName
        cell.createdAtLabel.text = tweet.createdAt
        
        if tweet.pictureURL != nil {
            if let imageData = NSData(contentsOfURL: tweet.pictureURL!) {
                cell.pictureImageView.image = UIImage(data: imageData)
            }
        }
        return cell
    }
    func requestTweets() {
        let accountStore = ACAccountStore()
        let twitterAccountType = accountStore.accountTypeWithAccountTypeIdentifier(ACAccountTypeIdentifierTwitter)
        accountStore.requestAccessToAccountsWithType(twitterAccountType, options: nil, completion: {
            (granted: Bool, error: NSError!) -> Void in
            if (!granted) {
                print("Access to Twitter Account denied")
            } else {
                let twitterAccounts = accountStore.accountsWithAccountType(twitterAccountType)
                if twitterAccounts.count == 0 {
                    print("No Twitter Accounts available")
                    return
                } else {
                    let twitterParams = [
                        "count" : "150"
                    ]
                    let twitterAPIURL = NSURL(string: "https://api.twitter.com/1.1/statuses/home_timeline.json")
                    let request = SLRequest(forServiceType: SLServiceTypeTwitter, requestMethod: SLRequestMethod.GET, URL: twitterAPIURL, parameters: twitterParams)
                    request.account = twitterAccounts.first as! ACAccount
                    request.performRequestWithHandler({
                        (data: NSData!, urlResponse: NSHTTPURLResponse!, error: NSError!) -> Void in self.handleTweetsResponse(data, urlResponse: urlResponse, error: error)
                    })
                }
            }
        })
    }
    func handleTweetsResponse(data: NSData!, urlResponse: NSHTTPURLResponse!, error: NSError!) {
        var tweets = [Tweet]()
        if let dataValue = data {
            let jsonObject: AnyObject?
            do {
                jsonObject = try NSJSONSerialization.JSONObjectWithData(dataValue, options: NSJSONReadingOptions(rawValue: 0))
            } catch let error as NSError {
                print(error)
                jsonObject = nil
            }
           
            if let jsonArray = jsonObject as? [[String: AnyObject]] {
                self.tweets.removeAll(keepCapacity: true)
                for tweetDict in jsonArray {
                    let tweetText = tweetDict["text"] as! String
                    let df = NSDateFormatter()
                    df.dateFormat = "EEE MMM d HH:mm:ss Z y"
                    let createdAtLong = tweetDict["created_at"] as! String
                    let createdAtShort = df.dateFromString(createdAtLong)
                    df.dateFormat = "EEE MMM d"
                    
                    let createdAt = df.stringFromDate(createdAtShort!)
                    let userDict = tweetDict["user"] as! NSDictionary
                    let userName = userDict["name"] as! String
                    let pictureURL = userDict["profile_image_url"] as! String
                    let tweet = Tweet(tweetText: tweetText, userName: userName, createdAt: createdAt, pictureURL: NSURL(string: pictureURL))
                    self.tweets.append(tweet)
                }
                self.tableView.reloadData()
            }
        } else {
            print("handleTwitterData received no data")
        }
    }

}

