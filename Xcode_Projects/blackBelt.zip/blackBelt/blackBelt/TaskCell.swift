//
//  TaskCell.swift
//  blackBelt
//
//  Created by Andrew Espidol on 9/11/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit
class TaskCell: UITableViewCell {
    @IBOutlet weak var taskLabel: UILabel!
}
