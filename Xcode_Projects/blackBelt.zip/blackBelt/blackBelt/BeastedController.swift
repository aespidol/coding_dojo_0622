//
//  BeastedController.swift
//  blackBelt
//
//  Created by Andrew Espidol on 9/11/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit
class BeastedController: UITableViewController {
    var beasted = Task.all()
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("BeastedCell") as! BeastedCell
        if beasted[indexPath.row].done == true {
        cell.completeLabel.text = beasted[indexPath.row].objective
        cell.dateLabel.text = String(beasted[indexPath.row].createdAt)
        }
        return cell
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var counter = 0
        for var i = 0; i < beasted.count; ++i{
            if  beasted[i].done == true {
                counter++
            }
        }
        return counter
    }
    override func viewDidAppear(animated: Bool) {
        super.viewWillAppear(animated);
        tableView.reloadData()
    }
}
