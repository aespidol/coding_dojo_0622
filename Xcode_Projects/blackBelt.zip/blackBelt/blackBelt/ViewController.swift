//
//  ViewController.swift
//  blackBelt
//
//  Created by Andrew Espidol on 9/11/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

class ViewController: UITableViewController, CancelButtonDelegate, AddTaskDelegate {
    

    var tasks = Task.all()

    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print(tasks[indexPath.row].done)
        tasks[indexPath.row].done = true
        print(tasks[indexPath.row].done)
        tasks[indexPath.row].save()
        tableView.reloadData()
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("TaskCellid")! as! TaskCell
        cell.taskLabel.text = tasks[indexPath.row].objective
        return cell
    }
    func cancelButtonPressedFrom(controller: UIViewController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    override func tableView(tableView: UITableView, accessoryButtonTappedForRowWithIndexPath indexPath: NSIndexPath) {
        performSegueWithIdentifier("AddTask", sender: tableView.cellForRowAtIndexPath(indexPath))
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "AddTask" {
            let navigationController = segue.destinationViewController as! UINavigationController
            let controller = navigationController.topViewController as! AddTaskController
            controller.cancelButtonDelegate = self
            controller.delegate = self
            if sender!.tag != 1 {
                if let indexPath = tableView.indexPathForCell(sender as! UITableViewCell) {
                    controller.itemToEdit = tasks[indexPath.row]
                }
            }
        }
    }
    func AddTask(controller: AddTaskController, didFinishAddingTask task: String) {
        dismissViewControllerAnimated(true, completion: nil)
        let nTask = Task(obj: task)
        nTask.save()
        tasks = Task.all()
        tableView.reloadData()
    }
    func AddTask(controller: AddTaskController, didFinishEditingTask task: Task) {
        task.save()
        tasks = Task.all()
        tableView.reloadData()
    }
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        tasks[indexPath.row].destroy()
        tasks.removeAtIndex(indexPath.row)
        tableView.reloadData()
    }
}

