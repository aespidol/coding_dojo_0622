//
//  Beasted.swift
//  blackBelt
//
//  Created by Andrew Espidol on 9/11/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import Foundation
class Beast: NSObject, NSCoding {
    static var key: String = "Tasks"
    static var schema: String = "theList"
    var objective: String
    var createdAt: NSDate
    // use this init for creating a new Task
    init(obj: String) {
        objective = obj
        createdAt = NSDate()
    }
    // MARK: - NSCoding protocol
    // used for encoding (saving) objects
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(objective, forKey: "objective")
        aCoder.encodeObject(createdAt, forKey: "createdAt")
    }
    // used for decoding (loading) objects
    required init?(coder aDecoder: NSCoder) {
        objective = aDecoder.decodeObjectForKey("objective") as! String
        
        createdAt = aDecoder.decodeObjectForKey("createdAt") as! NSDate
        super.init()
    }
    // MARK: - Queries
    static func all() -> [Beast] {
        var beasts = [Beast]()
        let path = BeastDatabase.dataFilePath("theList")
        if NSFileManager.defaultManager().fileExistsAtPath(path) {
            if let data = NSData(contentsOfFile: path) {
                let unarchiver = NSKeyedUnarchiver(forReadingWithData: data)
                beasts = unarchiver.decodeObjectForKey(Beast.key) as! [Beast]
                unarchiver.finishDecoding()
            }
        }
        return beasts
    }
    func save() {
        var beastsFromStorage = Beast.all()
            beastsFromStorage.append(self)
        BeastDatabase.save(beastsFromStorage, toSchema: Task.schema, forKey: Task.key)
    }
    func destroy() {
        var beastsFromStorage = Beast.all()
        for var i = 0; i < beastsFromStorage.count; ++i {
            if beastsFromStorage[i].createdAt == self.createdAt {
                beastsFromStorage.removeAtIndex(i)
            }
        }
        BeastDatabase.save(beastsFromStorage, toSchema: Task.schema, forKey: Task.key)
    }
}