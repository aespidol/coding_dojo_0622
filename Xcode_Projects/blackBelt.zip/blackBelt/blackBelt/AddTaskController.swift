//
//  AddTaskController.swift
//  blackBelt
//
//  Created by Andrew Espidol on 9/11/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

class AddTaskController: UITableViewController {
    weak var cancelButtonDelegate: CancelButtonDelegate?
    
    @IBAction func cancelBarButtonPressed(sender: UIBarButtonItem) {
        cancelButtonDelegate?.cancelButtonPressedFrom(self)
    }
    
    weak var delegate: AddTaskDelegate?
    @IBOutlet weak var taskTextField: UITextField!
    
    @IBAction func doneBarButtonPressed(sender: AnyObject) {
        if let taskUpdate = itemToEdit {
            taskUpdate.objective = taskTextField.text!
            delegate?.AddTask(self, didFinishEditingTask: taskUpdate)
        }
        delegate?.AddTask(self, didFinishAddingTask: taskTextField.text!)
    }
    var itemToEdit: Task?
    override func viewDidLoad() {
        if let missionedit = itemToEdit {
            taskTextField.text = missionedit.objective
        }
    }
}
