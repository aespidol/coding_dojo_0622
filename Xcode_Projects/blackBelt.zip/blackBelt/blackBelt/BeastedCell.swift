//
//  BeastedCell.swift
//  blackBelt
//
//  Created by Andrew Espidol on 9/11/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit
class BeastedCell: UITableViewCell {
    
    @IBOutlet weak var completeLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
}
