//
//  MissionDetailsViewController.swift
//  bucketList
//
//  Created by Andrew Espidol on 9/7/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

class MissionDetailsViewController: UITableViewController {
    weak var cancelButtonDelegate: CancelButtonDelegate?
    @IBOutlet weak var newMissionText: UITextField!
    @IBAction func cancelBarButtonPressed(sender: UIBarButtonItem) {
        cancelButtonDelegate?.cancelButtonPressedFrom(self)
    }
    @IBAction func doneBarButtonPressed(sender: UIBarButtonItem) {
        delegate?.missionDetailsViewController(self, didFinishAddingMission: newMissionText.text!)
    }
    weak var delegate: MissionDetailsViewControllerDelegate?
}
