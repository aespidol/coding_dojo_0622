//
//  ViewController.swift
//  coldCall
//
//  Created by Andrew Espidol on 9/3/15.
//  Copyright © 2015 Andrew Espidol. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var name = ["Andrew", "Alex", "Jake","Alfred","Mila", "Linh", "Vanessa", "Kaya"]
    
    
    @IBOutlet weak var names: UILabel!
    
    @IBAction func coldCallButton(sender: AnyObject) {
        let nameIndex = arc4random_uniform(UInt32(name.count))
        names.text = name[Int(nameIndex)]
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func updateUI(){
        names.text = "Ready?"
    }


}

